
package com.lamichoacana.pos;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvGrid;
    private Button btnCobrar, btnBack, btnCarrito, btnHistorial, btnAdmin;
    private TextView tvSubTitle;
    private final List<Producto> carrito = new ArrayList<>();
    private MediaPlayer ding;

    private List<Producto> catalogo = new ArrayList<>();
    private static final String PREFS = "ventas_prefs";
    private static final String KEY_VENTAS = "ventas_json";
    private static final String KEY_NEXT_ID = "ventas_next_id";
    private static final String ADMIN_PREFS = "admin_prefs";
    private static final String KEY_PASS = "admin_pass";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvGrid = findViewById(R.id.rvGrid);
        btnCobrar = findViewById(R.id.btnCobrar);
        btnBack = findViewById(R.id.btnBack);
        btnCarrito = findViewById(R.id.btnCarrito);
        btnHistorial = findViewById(R.id.btnHistorial);
        btnAdmin = findViewById(R.id.btnAdmin);
        tvSubTitle = findViewById(R.id.tvSubTitle);
        ding = MediaPlayer.create(this, android.provider.Settings.System.DEFAULT_NOTIFICATION_URI);

        catalogo = CatalogoProvider.cargar(this, "productos.csv");
        rvGrid.setLayoutManager(new GridLayoutManager(this, 2));

        int countProductos = catalogo.size();
        int countCategorias = getCategoriasUnicas(catalogo).size();
        tvSubTitle.setText("Cargados: " + countCategorias + " categorías / " + countProductos + " productos");
        if (countProductos == 0) Toast.makeText(this, "No se cargaron productos — revisa encabezados/separador", Toast.LENGTH_LONG).show();

        mostrarCategorias();

        btnBack.setOnClickListener(v -> mostrarCategorias());
        btnCarrito.setOnClickListener(v -> mostrarCarrito());
        btnHistorial.setOnClickListener(v -> mostrarHistorial());
        btnAdmin.setOnClickListener(v -> abrirAdminProtegido());

        btnCobrar.setOnClickListener(v -> {
            double total = 0.0;
            for (Producto p : carrito) total += p.precio;
            if (carrito.isEmpty()) { Toast.makeText(this, "La cesta está vacía", Toast.LENGTH_SHORT).show(); return; }

            for (Producto p : carrito) for (Producto c : catalogo) if (c.nombre.equals(p.nombre)) c.stock = Math.max(0, c.stock - 1);
            CatalogoProvider.guardarStock(this, catalogo);

            ding.start();
            long id = nextVentaId();
            guardarVenta(id, total, new ArrayList<>(carrito));
            Toast.makeText(this, "Venta #" + id + " realizada: $" + String.format("%.2f", total), Toast.LENGTH_LONG).show();
            carrito.clear();
            actualizarTextoCarrito();
            if (rvGrid.getAdapter()!=null) rvGrid.getAdapter().notifyDataSetChanged();
        });
    }

    private void abrirAdminProtegido() {
        String pass = leerPass();
        if (pass == null || pass.isEmpty()) { startActivity(new Intent(this, AdminActivity.class)); return; }
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        new android.app.AlertDialog.Builder(this)
                .setTitle("Contraseña")
                .setView(input)
                .setPositiveButton("Entrar", (d, which) -> {
                    if (pass.equals(input.getText().toString())) startActivity(new Intent(this, AdminActivity.class));
                    else Toast.makeText(this, "Contraseña incorrecta", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private String leerPass() {
        SharedPreferences sp = getSharedPreferences(ADMIN_PREFS, Context.MODE_PRIVATE);
        return sp.getString(KEY_PASS, "");
    }

    private void mostrarCategorias() {
        btnBack.setVisibility(View.GONE);
        tvSubTitle.setText(getString(R.string.elige_categoria));
        List<String> categorias = getCategoriasUnicas(catalogo);
        rvGrid.setAdapter(new CategoryAdapter(categorias, this::mostrarProductosDeCategoria));
    }

    private void mostrarProductosDeCategoria(String categoria) {
        btnBack.setVisibility(View.VISIBLE);
        tvSubTitle.setText(categoria);
        List<Producto> filtrados = new ArrayList<>();
        for (Producto p : catalogo) if (p.categoria != null && p.categoria.equalsIgnoreCase(categoria)) filtrados.add(p);
        rvGrid.setAdapter(new ProductoAdapter(filtrados, p -> {
            if (p.stock <= 0) { Toast.makeText(this, "Sin stock", Toast.LENGTH_SHORT).show(); return; }
            carrito.add(p);
            Toast.makeText(this, p.nombre + " agregado", Toast.LENGTH_SHORT).show();
            actualizarTextoCarrito();
        }));
    }

    private List<String> getCategoriasUnicas(List<Producto> items) {
        Set<String> set = new LinkedHashSet<>();
        for (Producto p : items) if (p.categoria != null && !p.categoria.trim().isEmpty()) set.add(p.categoria.trim());
        return new ArrayList<>(set);
    }

    private void mostrarCarrito() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_cart, null);
        builder.setView(view);
        android.app.AlertDialog dialog = builder.create();

        RecyclerView rvCart = view.findViewById(R.id.rvCart);
        rvCart.setLayoutManager(new LinearLayoutManager(this));
        TextView tvCartTotal = view.findViewById(R.id.tvCartTotal);
        Button btnVaciar = view.findViewById(R.id.btnVaciar);
        Button btnCerrar = view.findViewById(R.id.btnCerrar);

        CartAdapter adapter = new CartAdapter(carrito, (p, position) -> {
            if (position >= 0 && position < carrito.size()) {
                carrito.remove(position);
                RecyclerView.Adapter a = rvCart.getAdapter();
                if (a instanceof CartAdapter) ((CartAdapter)a).notifyItemRemoved(position);
                actualizarTextoCarrito();
                actualizarTotalCarrito(tvCartTotal);
            }
        });
        rvCart.setAdapter(adapter);

        actualizarTextoCarrito();
        actualizarTotalCarrito(tvCartTotal);

        btnVaciar.setOnClickListener(v -> {
            carrito.clear();
            RecyclerView.Adapter a = rvCart.getAdapter();
            if (a instanceof CartAdapter) ((CartAdapter)a).notifyDataSetChanged();
            actualizarTextoCarrito();
            actualizarTotalCarrito(tvCartTotal);
        });

        btnCerrar.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void actualizarTextoCarrito() {
        if (btnCarrito != null) btnCarrito.setText(getString(R.string.ver_carrito, carrito.size()));
    }

    private void actualizarTotalCarrito(TextView tv) {
        double total = 0.0;
        for (Producto p : carrito) total += p.precio;
        tv.setText("Total: $" + String.format("%.2f", total));
    }

    private long nextVentaId() {
        SharedPreferences sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long next = sp.getLong(KEY_NEXT_ID, 1L);
        sp.edit().putLong(KEY_NEXT_ID, next + 1L).apply();
        return next;
    }

    private void guardarVenta(long id, double total, List<Producto> items) {
        List<Venta> ventas = cargarVentas();
        Venta v = new Venta();
        v.id = id;
        v.timestamp = System.currentTimeMillis();
        v.total = total;
        v.cancelada = false;
        v.items.addAll(items);
        ventas.add(0, v);
        guardarVentas(ventas);
    }

    private List<Venta> cargarVentas() {
        SharedPreferences sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String json = sp.getString(KEY_VENTAS, "[]");
        List<Venta> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(json);
            for (int i=0;i<arr.length();i++) out.add(Venta.fromJson(arr.getJSONObject(i)));
        } catch (JSONException e) { e.printStackTrace(); }
        return out;
    }

    private void guardarVentas(List<Venta> ventas) {
        JSONArray arr = new JSONArray();
        try { for (Venta v : ventas) arr.put(v.toJson()); } catch (JSONException e) { e.printStackTrace(); }
        SharedPreferences sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit().putString(KEY_VENTAS, arr.toString()).apply();
    }

    private void mostrarHistorial() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_history, null);
        builder.setView(view);
        android.app.AlertDialog dialog = builder.create();

        RecyclerView rvHistory = view.findViewById(R.id.rvHistory);
        rvHistory.setLayoutManager(new LinearLayoutManager(this));

        List<Venta> ventas = cargarVentas();
        HistoryAdapter adapter = new HistoryAdapter(ventas, (venta, position) -> {
            if (!venta.cancelada) {
                for (Producto p : venta.items) for (Producto c : catalogo) if (c.nombre.equals(p.nombre)) c.stock += 1;
                CatalogoProvider.guardarStock(this, catalogo);

                venta.cancelada = true;
                guardarVentas(ventas);
                RecyclerView.Adapter a = rvHistory.getAdapter();
                if (a instanceof HistoryAdapter) ((HistoryAdapter)a).notifyItemChanged(position);
                Toast.makeText(this, "Venta #" + venta.id + " cancelada", Toast.LENGTH_SHORT).show();
                if (rvGrid.getAdapter()!=null) rvGrid.getAdapter().notifyDataSetChanged();
            }
        });
        rvHistory.setAdapter(adapter);

        dialog.show();
    }

    private List<String> getCategoriasUnicas(List<Producto> items) {
        Set<String> set = new LinkedHashSet<>();
        for (Producto p : items) if (p.categoria != null && !p.categoria.trim().isEmpty()) set.add(p.categoria.trim());
        return new ArrayList<>(set);
    }
}
