
plugins {
  id("com.android.application") version "8.4.1" apply false
}
