
package com.lamichoacana.pos;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CatalogoProvider {
    private static final String PREFS = "inventario_prefs";
    private static final String KEY_STOCK = "stock_json";

    public static List<Producto> cargar(Context ctx, String assetName) {
        List<Producto> lista = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(ctx.getAssets().open(assetName)))) {
            String header = reader.readLine();
            if (header == null) return lista;
            if (header.length() > 0 && header.charAt(0) == '\ufeff') header = header.substring(1);
            List<String> hcols = parseCSVLine(header);
            int iCat = indexOfHeader(hcols, new String[]{"categoria","categoría"});
            int iNom = indexOfHeader(hcols, new String[]{"nombre del producto","producto","nombre"});
            int iPre = indexOfHeader(hcols, new String[]{"precio"});
            int iSto = indexOfHeader(hcols, new String[]{"stock","existencias"});
            int iCod = indexOfHeader(hcols, new String[]{"código de barras","codigo de barras","codigo","código"});
            int iImg = indexOfHeader(hcols, new String[]{"imagen","foto"});

            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                List<String> cols = parseCSVLine(line);
                String categoria = getCol(cols, iCat);
                String nombre = getCol(cols, iNom);
                if (nombre == null || nombre.trim().isEmpty()) continue;
                double precio = parsePrecio(getCol(cols, iPre));
                int stock = parseEntero(getCol(cols, iSto));
                String codigo = getCol(cols, iCod);
                String imagen = getCol(cols, iImg);
                lista.add(new Producto(
                        categoria == null ? "" : categoria.trim(),
                        nombre.trim(),
                        precio,
                        stock,
                        (codigo == null || codigo.trim().isEmpty()) ? null : codigo.trim(),
                        (imagen == null || imagen.trim().isEmpty()) ? null : imagen.trim()
                ));
            }
        } catch (IOException e) { e.printStackTrace(); }

        Map<String,Integer> persisted = leerStock(ctx);
        for (Producto p : lista) {
            Integer s = persisted.get(p.nombre);
            if (s != null) p.stock = s;
        }
        return lista;
    }

    public static void guardarStock(Context ctx, List<Producto> lista) {
        Map<String,Integer> map = new LinkedHashMap<>();
        for (Producto p : lista) map.put(p.nombre, p.stock);
        escribirStock(ctx, map);
    }

    private static Map<String,Integer> leerStock(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String json = sp.getString(KEY_STOCK, "{}");
        Map<String,Integer> out = new LinkedHashMap<>();
        try {
            JSONObject obj = new JSONObject(json);
            Iterator<String> it = obj.keys();
            while (it.hasNext()) {
                String k = it.next();
                out.put(k, obj.getInt(k));
            }
        } catch (JSONException e) { e.printStackTrace(); }
        return out;
    }

    private static void escribirStock(Context ctx, Map<String,Integer> map) {
        JSONObject obj = new JSONObject();
        try {
            for (Map.Entry<String,Integer> e : map.entrySet()) obj.put(e.getKey(), e.getValue());
        } catch (JSONException ex) { ex.printStackTrace(); }
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit().putString(KEY_STOCK, obj.toString()).apply();
    }

    public static List<String> categorias(List<Producto> items) {
        Set<String> set = new LinkedHashSet<>();
        for (Producto p : items) if (p.categoria != null && !p.categoria.trim().isEmpty()) set.add(p.categoria.trim());
        return new ArrayList<>(set);
    }

    private static int indexOfHeader(List<String> headers, String[] candidates) {
        for (int i = 0; i < headers.size(); i++) {
            String h = headers.get(i) == null ? "" : headers.get(i).trim().toLowerCase();
            for (String c : candidates) if (h.equals(c)) return i;
        }
        return -1;
    }

    private static String getCol(List<String> cols, int idx) {
        if (idx < 0 || idx >= cols.size()) return null;
        String v = cols.get(idx);
        if (v == null) return null;
        if (v.length() >= 2 && v.charAt(0) == '"' && v.charAt(v.length()-1) == '"') v = v.substring(1, v.length()-1);
        return v;
    }

    private static List<String> parseCSVLine(String line) {
        char delim = autoDelimiter(line);
        List<String> out = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"') {
                if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '"') { sb.append('"'); i++; }
                else { inQuotes = !inQuotes; }
            } else if (ch == delim && !inQuotes) { out.add(sb.toString()); sb.setLength(0); }
            else { sb.append(ch); }
        }
        out.add(sb.toString());
        return out;
    }

    private static char autoDelimiter(String sample) {
        int c = countOf(sample, ',');
        int s = countOf(sample, ';');
        int t = countOf(sample, '\t');
        if (s > c && s >= t) return ';';
        if (t > c && t >= s) return '\t';
        return ',';
    }

    private static int countOf(String s, char ch) { int k = 0; for (int i=0;i<s.length();i++) if (s.charAt(i)==ch) k++; return k; }

    private static double parsePrecio(String s) {
        if (s == null) return 0.0;
        try { s = s.replace("$","").replace("MXN","").replace("mxn","").trim(); s = s.replace(",", "."); return Double.parseDouble(s); }
        catch (Exception e) { return 0.0; }
    }
    private static int parseEntero(String s) {
        if (s == null) return 0;
        try { s = s.replaceAll("[^0-9-]",""); if (s.isEmpty()) return 0; return Integer.parseInt(s); }
        catch (Exception e) { return 0; }
    }
}
