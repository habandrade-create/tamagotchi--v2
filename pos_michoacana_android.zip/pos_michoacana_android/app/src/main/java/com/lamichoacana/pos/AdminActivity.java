
package com.lamichoacana.pos;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdminActivity extends AppCompatActivity {

    private static final String PREFS = "admin_prefs";
    private static final String KEY_PASS = "admin_pass";

    private EditText edtPassword;
    private RecyclerView rvStock;
    private List<Producto> catalogo;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        edtPassword = findViewById(R.id.edtPassword);
        rvStock = findViewById(R.id.rvStock);
        Button btnSavePassword = findViewById(R.id.btnSavePassword);
        Button btnSmsPassword = findViewById(R.id.btnSmsPassword);

        String pass = leerPass();
        if (!TextUtils.isEmpty(pass)) edtPassword.setText(pass);

        catalogo = CatalogoProvider.cargar(this, "productos.csv");
        rvStock.setLayoutManager(new LinearLayoutManager(this));

        final StockAdapter adapter = new StockAdapter(catalogo, (p, delta) -> {
            int idx = catalogo.indexOf(p);
            p.stock = Math.max(0, p.stock + delta);
            RecyclerView.Adapter a = rvStock.getAdapter();
            if (a instanceof StockAdapter && idx >= 0) ((StockAdapter)a).notifyItemChanged(idx);
            CatalogoProvider.guardarStock(this, catalogo);
        });
        rvStock.setAdapter(adapter);

        btnSavePassword.setOnClickListener(v -> {
            String newPass = edtPassword.getText().toString();
            guardarPass(newPass);
            Toast.makeText(this, "Contraseña guardada", Toast.LENGTH_SHORT).show();
        });

        btnSmsPassword.setOnClickListener(v -> {
            String currentPass = edtPassword.getText().toString();
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("smsto:+525538528808"));
            intent.putExtra("sms_body", "Contraseña admin: " + currentPass);
            startActivity(intent);
        });
    }

    private String leerPass() {
        SharedPreferences sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return sp.getString(KEY_PASS, "");
    }

    private void guardarPass(String pass) {
        SharedPreferences sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit().putString(KEY_PASS, pass).apply();
    }
}
