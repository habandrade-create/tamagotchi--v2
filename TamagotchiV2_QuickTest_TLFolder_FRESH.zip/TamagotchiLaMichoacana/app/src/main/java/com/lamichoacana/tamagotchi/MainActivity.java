
package com.lamichoacana.tamagotchi;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS = "tama";
    private static final String KEY_START = "eggStartAtMs";
    private static final long HATCH_MS = 6_000L; // Quick test

    private ImageView imgEgg, imgCrack, imgPet;
    private SharedPreferences prefs;
    private long startAtMs;
    private ObjectAnimator wobbleAnimator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        imgEgg   = findViewById(R.id.imgEgg);
        imgCrack = findViewById(R.id.imgCrack);
        imgPet   = findViewById(R.id.imgPet);

        startAtMs = prefs.getLong(KEY_START, 0L);
        if (startAtMs == 0L) {
            startAtMs = System.currentTimeMillis();
            prefs.edit().putLong(KEY_START, startAtMs).apply();
        }

        long elapsed = System.currentTimeMillis() - startAtMs;
        if (elapsed >= HATCH_MS) {
            showPetInstant();
        } else {
            startEggWobble();
            long remaining = HATCH_MS - elapsed;
            imgEgg.postDelayed(this::playCrackSequence, remaining);
        }
    }

    private void startEggWobble() {
        PropertyValuesHolder rot1 = PropertyValuesHolder.ofFloat(View.ROTATION, -4f, 4f);
        PropertyValuesHolder ty1  = PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, 0f, -6f, 0f, 6f, 0f);
        wobbleAnimator = ObjectAnimator.ofPropertyValuesHolder(imgEgg, rot1, ty1);
        wobbleAnimator.setDuration(1200);
        wobbleAnimator.setRepeatCount(ValueAnimator.INFINITE);
        wobbleAnimator.setRepeatMode(ValueAnimator.REVERSE);
        wobbleAnimator.setInterpolator(new LinearInterpolator());
        wobbleAnimator.start();
    }

    private void playCrackSequence() {
        if (wobbleAnimator != null) wobbleAnimator.cancel();

        ObjectAnimator shake = ObjectAnimator.ofFloat(imgEgg, View.ROTATION, -12f, 12f, -12f, 12f, 0f);
        shake.setDuration(600);
        shake.setInterpolator(new LinearInterpolator());

        imgCrack.setAlpha(0f);
        imgCrack.setVisibility(View.VISIBLE);
        ObjectAnimator crackAlpha = ObjectAnimator.ofFloat(imgCrack, View.ALPHA, 0f, 1f);
        crackAlpha.setDuration(380);
        ObjectAnimator crackScaleX = ObjectAnimator.ofFloat(imgCrack, View.SCALE_X, 0.9f, 1.05f, 1f);
        ObjectAnimator crackScaleY = ObjectAnimator.ofFloat(imgCrack, View.SCALE_Y, 0.9f, 1.05f, 1f);
        crackScaleX.setDuration(380);
        crackScaleY.setDuration(380);

        ObjectAnimator eggFade   = ObjectAnimator.ofFloat(imgEgg, View.ALPHA, 1f, 0f);
        ObjectAnimator eggScaleX = ObjectAnimator.ofFloat(imgEgg, View.SCALE_X, 1f, 1.15f, 0.8f);
        ObjectAnimator eggScaleY = ObjectAnimator.ofFloat(imgEgg, View.SCALE_Y, 1f, 1.15f, 0.8f);
        eggFade.setDuration(480); eggScaleX.setDuration(480); eggScaleY.setDuration(480);

        ObjectAnimator crackFade = ObjectAnimator.ofFloat(imgCrack, View.ALPHA, 1f, 0f);
        crackFade.setDuration(480);

        imgPet.setScaleX(0.7f); imgPet.setScaleY(0.7f); imgPet.setAlpha(0f);
        imgPet.setVisibility(View.VISIBLE);

        TimeInterpolator bounce = t -> {
            double x = t;
            return (float)(Math.pow(Math.E, -6*x) * Math.cos(20*x) * -1 + 1);
        };
        ObjectAnimator petAlpha = ObjectAnimator.ofFloat(imgPet, View.ALPHA, 0f, 1f);
        petAlpha.setDuration(600);
        ObjectAnimator petScaleX = ObjectAnimator.ofFloat(imgPet, View.SCALE_X, 0.7f, 1f);
        ObjectAnimator petScaleY = ObjectAnimator.ofFloat(imgPet, View.SCALE_Y, 0.7f, 1f);
        petScaleX.setDuration(700); petScaleY.setDuration(700);
        petScaleX.setInterpolator(bounce);
        petScaleY.setInterpolator(bounce);

        AnimatorSet set = new AnimatorSet();
        set.play(shake);
        set.play(crackAlpha).with(crackScaleX).with(crackScaleY).after(shake);
        set.play(eggFade).with(eggScaleX).with(eggScaleY).with(crackFade).after(crackAlpha);
        set.play(petAlpha).with(petScaleX).with(petScaleY).after(eggFade);

        set.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
                imgEgg.setVisibility(View.GONE);
                imgCrack.setVisibility(View.GONE);
            }
        });
        set.start();
    }

    private void showPetInstant() {
        if (wobbleAnimator != null) wobbleAnimator.cancel();
        imgEgg.setVisibility(View.GONE);
        imgCrack.setVisibility(View.GONE);
        imgPet.setAlpha(1f);
        imgPet.setScaleX(1f);
        imgPet.setScaleY(1f);
        imgPet.setVisibility(View.VISIBLE);
    }
}
